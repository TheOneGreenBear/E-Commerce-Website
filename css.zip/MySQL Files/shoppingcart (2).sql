-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 04, 2018 at 03:03 PM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoppingcart`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE IF NOT EXISTS `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` text COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `total_price` float(10,2) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
CREATE TABLE IF NOT EXISTS `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(5) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `price` float(10,2) NOT NULL,
  `picture` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '/img/items/placeholder.png',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `picture`, `created`, `modified`, `status`) VALUES
(1, 'GTX Nvidia 1080TI', 'The GeForce GTX 1080 Ti is NVIDIAs new flagship gaming GPU, based on the NVIDIA Pascal  architecture. The latest addition to the ultimate gaming platform.', 1000.00, '/img/items/placeholder.png', '2017-05-24 00:00:00', '2017-05-24 00:00:00', '1'),
(2, 'Intel I7 5820K', 'The Intel Core i7-5820K is an entry level Premium Performance proccesor codenamed Haswell-E that is fully unlocked, it is a K-Series proccesor that utilises the Haswell-E architecture featuring 6 cores and 12 thereads. ', 20.00, '/img/items/placeholder.png', '2017-05-24 00:00:00', '2017-05-24 00:00:00', '1'),
(3, 'AMD Ryzen 7 Processors', 'The Pinnacle of Modern Multi-Core Processing Power\r\n\r\n3.6 GHz clock rate with 4.0 GHz Precision Boost\r\nExtended Frequency Range (XFR) in the presence of better cooling\r\n95 Watt TDP', 5.00, '/img/items/placeholder.png', '2017-05-24 00:00:00', '2017-05-24 00:00:00', '1'),
(4, 'Linus Tech Tips', 'He\'s Canadian!', 1337.00, '/img/items/placeholder.png', '2017-05-24 00:00:00', '2017-05-24 00:00:00', '1'),
(5, 'Alienware 15', 'Alienwares most powerful 15-inch gaming laptop ever, engineered with 187 of the gaming graphics performance of previous generations with NVIDIA GeForce GTX 10 Series graphics', 45.00, '/img/items/alienwarer15.png', '2017-05-24 00:00:00', '2017-05-24 00:00:00', '1'),
(6, 'Dell UltraSharp 32 8K Monitor', 'Experience realistic images like never before on the award-winning, world’s first 31.5 8K monitor featuring Dell PremierColor', 34.00, '/img/items/Dell8Kmonitor.png', '2017-05-24 00:00:00', '2017-05-24 00:00:00', '1');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
