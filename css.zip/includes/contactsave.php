<?php
@$savedata = $_REQUEST['savedata'];
if ($savedata == 1){ 

$data = $_POST['name']."\r\n";
$data .= $_POST['email'] . "\r\n";
$data .= $_POST['message'] . "\r\n";
$file = "contact.txt"; 

$fp = fopen($file, "a") or die("Couldn't open $file for writing!");
 $savestring = 'Name:'. " " . $_POST['name']. '<br>' . 'Email:' . " " . $_POST['email']. " " . 'Message:'. " " . $_POST['message'];
fwrite($fp, $savestring) or die("Couldn't write values to file!"); 

fclose($fp); 
echo "Your Form has been Submitted!";

}
?>